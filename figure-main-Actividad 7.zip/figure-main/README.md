# figure
Uso correcto de IMG y FIGURE
